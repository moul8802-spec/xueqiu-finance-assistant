import { requireChatGPTUser } from '@/app/chatgpt-auth';
import { ReviewDashboard } from '@/app/review-dashboard';
import { env } from 'cloudflare:workers';

export const dynamic = 'force-dynamic';

export default async function Home() {
  // Production stays sign-in gated. Local simulation mode is intentionally
  // usable without the Sites authentication dispatcher so the full workflow
  // can be tested before deployment.
  if (env.SIMULATION_MODE !== 'true') await requireChatGPTUser('/');
  return <ReviewDashboard />;
}
