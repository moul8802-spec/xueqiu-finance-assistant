import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '@/app/chatgpt-auth';

export async function dashboardActor() {
  const identity = await dashboardIdentity();
  return identity?.email ?? null;
}

export async function dashboardIdentity() {
  const user = await getChatGPTUser();
  if (user) return { id: user.userId, email: user.email, displayName: user.displayName };
  if (env.SIMULATION_MODE === 'true') {
    return { id: 'local-simulator', email: 'local-simulator', displayName: '本地测试用户' };
  }
  return null;
}

export function jsonError(message: string, status: number, code?: string | number, details?: unknown) {
  return Response.json({ ok: false, error: message, code, details }, { status });
}
